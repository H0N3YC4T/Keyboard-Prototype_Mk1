#ifndef CUSTOM_FONTS_H
#define CUSTOM_FONTS_H

LV_FONT_DECLARE(pixel_operator_mono);

#endif